/*
Just draw a border round the document.body.
*/
document.getElementsByClassName("fr-fic")[0].src="https://i.imgur.com/J2iqGJE.png";
//console.log("Hello World");