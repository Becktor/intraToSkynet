/*
Just draw a border round the document.body.
*/
document.getElementsByClassName("fr-fic")[0].src="https://i.imgur.com/J2iqGJE.png";
document.title = '3Shape Skynet';
//console.log("Hello World");